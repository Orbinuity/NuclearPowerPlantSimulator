# Nuclear Power Plant Simulator

[<img alt="Status" src="https://raw.githubusercontent.com/Orbinuity/.github/main/status/stable.png" width="100" height="25">](https://orbinuity.github.io/statusIcons.html)

An nuclear power plant simulator

## License

Before copying any part of this project, please read the [LICENSE](./LICENSE) file to understand the terms and conditions.